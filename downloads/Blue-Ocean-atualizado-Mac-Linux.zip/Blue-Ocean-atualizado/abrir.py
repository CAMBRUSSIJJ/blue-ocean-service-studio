from pathlib import Path
import os, runpy, threading, webbrowser
base = Path(__file__).resolve().parent
# The existing Linux server opens the browser through xdg-open when available.
import shutil
if not ((os.environ.get('DISPLAY') or os.environ.get('WAYLAND_DISPLAY')) and shutil.which('xdg-open')):
    timer = threading.Timer(1, lambda: webbrowser.open('http://127.0.0.1:4173/'))
    timer.daemon = True
    timer.start()
runpy.run_path(str(base / 'scripts' / 'serve-linux.py'), run_name='__main__')
